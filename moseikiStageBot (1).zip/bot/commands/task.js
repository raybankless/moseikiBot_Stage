// bot/commands/task.js
const { setUserState, getUserState, clearUserState } = require('../state');
const logger = require('../../utils/logger');
const axios = require('axios');
const path = require('path');
const { downloadFile, uploadImageToJira } = require('../../utils/file');
const { jiraUrl, jiraEmail, jiraApiToken, telegramToken } = require('../../config');
const JiraBoard = require('../../data/models/jiraBoardModel');
const JiraContributor = require('../../data/models/jiraContributorModel');

async function handleTaskCommand(bot, msg) {
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name;
  const channelName = msg.chat.title || "DirectMessage";
  const state = await getUserState(userId) || {};

  if (state.step) {
    bot.sendMessage(userId, `You are already in the middle of another process. Please complete it or use /stop to start over.`);
    return;
  }

  state.step = 'task_selectBoard';
  state.username = username;
  state.channelName = channelName;
  state.originalChatId = msg.chat.id;
  await setUserState(userId, state);

  try {
    const boards = await JiraBoard.find({});
    if (boards.length === 0) {
      bot.sendMessage(userId, "No boards found.");
      logger.warn("No Jira boards found in the database.");
      return;
    }
    const boardButtons = boards.map(board => [{ text: board.name }]);
    bot.sendMessage(userId, "Please select the board to create the issue:", {
      reply_markup: {
        keyboard: boardButtons,
        one_time_keyboard: true,
        resize_keyboard: true
      },
    });
    logger.info(`Boards fetched successfully: ${boards.map(board => board.name).join(', ')}`);
  } catch (error) {
    logger.error(`Failed to fetch Jira boards: ${error.message}`);
    bot.sendMessage(userId, "Failed to fetch Jira boards. Please try again later.");
  }
}

async function handleTaskSteps(bot, msg) {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const state = await getUserState(userId) || {};

  if (!state.step || msg.text === '/stop') {
    await clearUserState(userId);
    bot.sendMessage(chatId, "Process stopped. You can start again with /bug or /task.");
    return;
  }

  try {
    if (state.step === 'task_description' && chatId === userId) {
      state.description = msg.text;
      state.step = 'task_selectAssignee';
      await setUserState(userId, state);

      const contributors = await JiraContributor.find({});
      const assigneeButtons = contributors.map(contributor => [{ text: contributor.displayName }]);
      assigneeButtons.unshift([{ text: 'Me' }]);
      bot.sendMessage(chatId, 'Please select an assignee:', {
        reply_markup: {
          keyboard: assigneeButtons,
          one_time_keyboard: true,
          resize_keyboard: true
        },
      });
    } else if (state.step === 'task_screenshot' && msg.photo && chatId === userId) {
      const photo = msg.photo[msg.photo.length - 1];
      const fileId = photo.file_id;
      const file = await bot.getFile(fileId);
      const fileUrl = `https://api.telegram.org/file/bot${telegramToken}/${file.file_path}`;
      const localFilePath = path.join(__dirname, '../../temp', file.file_path.split('/').pop());

      try {
        await downloadFile(fileUrl, localFilePath);
        logger.info(`Screenshot downloaded to ${localFilePath}`);

        const payload = {
          fields: {
            project: { key: state.projectKey },
            summary: state.description,
            issuetype: { name: "Task" },
            assignee: { id: state.assignee },
          },
        };

        const options = {
          method: "post",
          url: `https://moseikiapp.atlassian.net/rest/api/3/issue`,
          headers: {
            Authorization: `Basic ${Buffer.from(`${jiraEmail}:${jiraApiToken}`).toString('base64')}`,
            "Content-Type": "application/json",
          },
          data: payload,
        };

        logger.info(`Jira issue creation URL: ${options.url}`);
        logger.info(`Jira issue creation payload: ${JSON.stringify(payload)}`);

        try {
          const response = await axios(options);
          if (response.status === 201) {
            const issueKey = response.data.key;
            await uploadImageToJira(issueKey, localFilePath);
            bot.sendMessage(chatId, `Task created successfully! Issue key: ${issueKey}`);
            logger.info("Task created successfully!");
          } else {
            bot.sendMessage(chatId, `Failed to create task: ${JSON.stringify(response.data)}`);
            logger.error(`Failed to create task: ${JSON.stringify(response.data)}`);
          }
        } catch (error) {
          const errorMessage = error.response ? JSON.stringify(error.response.data) : error.message;
          bot.sendMessage(chatId, `Failed to create Jira issue: ${errorMessage}`);
          logger.error(`Failed to create Jira issue: ${errorMessage}`);
        }
      } catch (error) {
        logger.error(`Failed to download the image: ${error.message}`);
        bot.sendMessage(chatId, `Failed to download the image: ${error.message}`);
      }

      await clearUserState(userId);
    }
  } catch (error) {
    logger.error("Error handling message:", error);
    bot.sendMessage(chatId, "Something went wrong. Please try again.");
    await clearUserState(userId);
  }
}

async function handleTaskCallbackQuery(bot, query) {
  const userId = query.from.id;
  const state = await getUserState(userId) || {};

  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const data = query.data;

  try {
    logger.info(`Callback query received: ${data}`);
    if (data.startsWith('board_')) {
      state.projectKey = data.replace('board_', '');
      state.step = 'task_description';
      await setUserState(userId, state);
      await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: chatId, message_id: messageId });
      bot.sendMessage(chatId, 'Please enter the task description.');
    } else if (data.startsWith('assignee_')) {
      const assignee = data.replace('assignee_', '');
      state.assignee = assignee === 'me' ? userId : assignee;
      state.step = 'task_screenshot';
      await setUserState(userId, state);
      await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: chatId, message_id: messageId });
      bot.sendMessage(chatId, 'Please upload the screenshot for the task.', {
        reply_markup: { remove_keyboard: true },
      });
    }
  } catch (error) {
    logger.error("Error handling callback query:", error);
    bot.sendMessage(chatId, "Something went wrong. Please try again.");
    await clearUserState(userId);
  }
}

module.exports = {
  handleTaskCommand,
  handleTaskSteps,
  handleTaskCallbackQuery
};