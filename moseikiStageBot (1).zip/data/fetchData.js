// data/fetchData.js
const axios = require('axios');
const JiraBoard = require('../data/models/jiraBoardModel');
const JiraContributor = require('../data/models/jiraContributorModel');
const ChannelMapping = require('../data/models/channelMappingModel');
const { jiraUrl, jiraEmail, jiraApiToken, channelMapping, projectKey } = require('../config');
const Link = require('../data/models/linksModel');
const Device = require('../data/models/deviceModel');

async function fetchJiraBoards() {
  const options = {
    method: 'GET',
    url: `${jiraUrl}/rest/agile/1.0/board`,
    headers: {
      Authorization: `Basic ${Buffer.from(`${jiraEmail}:${jiraApiToken}`).toString('base64')}`,
      'Content-Type': 'application/json'
    }
  };

  try {
    const response = await axios(options);
    const boards = response.data.values.map(board => ({
      boardId: board.id, // Ensure boardId is included
      projectKey: board.location.projectKey, // Map projectKey correctly
      name: board.name
    }));

    await JiraBoard.deleteMany({});
    await JiraBoard.insertMany(boards);
    console.log('Jira boards updated with project keys.');
  } catch (error) {
    console.error('Error fetching Jira boards:', error);
  }
}

async function fetchJiraContributors() {
  const options = {
    method: 'GET',
    url: `${jiraUrl}/rest/api/3/user/assignable/search?project=${projectKey}`,
    headers: {
      Authorization: `Basic ${Buffer.from(`${jiraEmail}:${jiraApiToken}`).toString('base64')}`,
      'Content-Type': 'application/json'
    }
  };

  try {
    const response = await axios(options);
    const contributors = response.data.map(user => ({
      accountId: user.accountId,
      displayName: user.displayName
    }));

    await JiraContributor.deleteMany({});
    await JiraContributor.insertMany(contributors);
    console.log('Jira contributors updated.');
  } catch (error) {
    console.error('Error fetching Jira contributors:', error);
  }
}

async function fetchChannelMappings() {
  try {
    const mappings = await ChannelMapping.find({});
    if (!mappings) throw new Error('No channel mappings found');

    console.log('Channel mappings fetched from database.');
    return mappings;
  } catch (error) {
    console.error('Error fetching channel mappings:', error);
  }
}

async function fetchLinks() {
  const notionLinks = [
    { category: 'notion', text: "Employee Directory", url: "https://www.notion.so/moseiki/e68e6f5219ec4d5bae8fbe0689860b7d?v=e1a7d9d1d5134bfa91ccc5923f74555c&pvs=4" },
    { category: 'notion', text: "Meeting Notes", url: "https://www.notion.so/moseiki/9ff29d36ed114a599cfe7384452a579f?v=b6f3883d68b0408f9bdb38a562a61db0&pvs=4" },
    { category: 'notion', text: "Release Notes", url: "https://www.notion.so/moseiki/fc0fbcb9e67c417ca6257b95c4a8539b?v=ea72be6eff314fa9931a7f09a8880de2&pvs=4" }
  ];

  const jiraLinks = [
    { category: 'jira', text: "Jira - Backend", url: "https://moseikiapp.atlassian.net/jira/software/projects/BACMOS/list" },
    { category: 'jira', text: "Jira - Product", url: "https://moseikiapp.atlassian.net/jira/software/projects/MOP/list" },
    { category: 'jira', text: "Jira - Web", url: "https://moseikiapp.atlassian.net/jira/software/projects/WEB/list" },
    { category: 'jira', text: "Jira - Bug Reports", url: "https://moseikiapp.atlassian.net/browse/MOP-87" }
  ];

  const figmaLinks = [
    { category: 'figma', text: "Figma - App", url: "https://www.figma.com/design/DGWmpECVwekRgljaMOYGXb/Moseiki-App?node-id=1-23564&t=o67iYRLbjf2Mcnnq-1" },
    { category: 'figma', text: "Figma - Web", url: "https://www.figma.com/design/wNsH2jaZy1dt0tFE94XFq3/Moseiki-Web-Site-1.0?node-id=149-2015&t=o67iYRLbjf2Mcnnq-1" },
    { category: 'figma', text: "Help Center", url: "https://moseiki.gitbook.io/help-center/" }
  ];

  const allLinks = [...notionLinks, ...jiraLinks, ...figmaLinks];

  await Link.deleteMany({});
  await Link.insertMany(allLinks);
  console.log('Links updated.');
}

async function getSavedDevices(userId) {
  try {
    const devices = await Device.find({ userId });
    return devices;
  } catch (error) {
    logger.error(`Error fetching devices for user ${userId}: ${error.message}`);
    return [];
  }
}

module.exports = {
  fetchJiraBoards,
  fetchJiraContributors,
  fetchChannelMappings,
  fetchLinks,
  getSavedDevices
};
