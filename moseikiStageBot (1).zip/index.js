// index.js
const bot = require('./bot/handlers');
const server = require('./server/index');

console.log("Application started.");