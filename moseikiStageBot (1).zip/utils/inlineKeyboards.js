// utils/inlineKeyboards.js
function getOperatingSystemKeyboard(operatingSystems) {
  const buttons = operatingSystems.map((os) => [{ text: os, callback_data: `os_${os}` }]);
  return { reply_markup: { inline_keyboard: buttons } };
}

const getAppVersionKeyboard = (appVersions) => {
    const versionButtons = appVersions.map(version => [{ text: version, callback_data: `app_${version}` }]);
    versionButtons.push([{ text: '+ Add New Version', callback_data: 'new_version' }]);
    return { inline_keyboard: versionButtons };
};

const getContinueKeyboard = () => ({
  inline_keyboard: [
    [{ text: "No Upload", callback_data: "bug_continue_no_upload" }]
  ]
});

const getUploadMoreKeyboard = () => ({
  inline_keyboard: [
    [{ text: "Yes", callback_data: "bug_upload_more_yes" }],
    [{ text: "No Upload", callback_data: "bug_upload_more_no" }]
  ]
});


module.exports = {
  getOperatingSystemKeyboard,
  getAppVersionKeyboard,
  getContinueKeyboard,
  getUploadMoreKeyboard
};